# Install Kindle Puppet Module for Boxen

Read more than 1 million* Kindle books on your computer with the free Kindle reading app. No Kindle device required. Whispersync technology syncs your last page read, bookmarks, notes, and highlights across various devices. 

See http://www.amazon.com/gp/feature.html/ref=kcp_mac_ln_ar?docId=1000464931 for more. 

## Usage

```include kindle```


## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
